import ThemeOptions from './ThemeOptions';

export default {
    ThemeOptions
};